from django.contrib import admin
from .models import (
    Categoria,
    Producto,
    Proveedor,
    ProductosProveedor,
    Pedido,
    DetallePedido,
    Carrito,
    MetodoPago,
    Pago,
)

admin.site.register(Categoria)
admin.site.register(Producto)
admin.site.register(Proveedor)
admin.site.register(ProductosProveedor)
admin.site.register(Pedido)
admin.site.register(DetallePedido)
admin.site.register(Carrito)
admin.site.register(MetodoPago)
admin.site.register(Pago)
