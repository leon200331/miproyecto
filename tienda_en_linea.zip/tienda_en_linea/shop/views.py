from django.shortcuts import render, get_object_or_404, redirect
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required
from django.urls import reverse_lazy
from django.views.generic import ListView, CreateView, UpdateView, DeleteView
from .models import Producto, Pedido, DetallePedido, Categoria
from .forms import ProductoForm
from django.db import transaction
from django.contrib import messages
import random

# Mostrar catálogo con select_related para optimizar la consulta
def catalogo(request):
    productos = Producto.objects.select_related('categoria').all()
    return render(request, 'shop/catalogo.html', {'productos': productos})

# Agregar al carrito
@require_POST
def agregar_al_carrito(request, producto_id):
    carrito = request.session.get('carrito', {})
    try:
        cantidad = int(request.POST.get('cantidad', 1))
        if cantidad < 1:
            cantidad = 1
    except (ValueError, TypeError):
        cantidad = 1

    if str(producto_id) in carrito:
        carrito[str(producto_id)]['cantidad'] += cantidad
    else:
        producto = get_object_or_404(Producto, id=producto_id)
        carrito[str(producto_id)] = {
            'nombre_producto': producto.nombre_producto,
            'precio': float(producto.precio),
            'cantidad': cantidad,
        }

    request.session['carrito'] = carrito
    messages.success(request, f'Se agregó {cantidad} x {carrito[str(producto_id)]["nombre_producto"]} al carrito.')
    return redirect('catalogo')

# Ver carrito
def ver_carrito(request):
    carrito = request.session.get('carrito', {})
    total = 0
    for key, item in carrito.items():
        item['subtotal'] = item['precio'] * item['cantidad']
        total += item['subtotal']
    return render(request, 'shop/carrito.html', {'carrito': carrito, 'total': total})

# Modificar cantidad en carrito
@require_POST
def modificar_cantidad(request, producto_id):
    try:
        cantidad = int(request.POST.get('cantidad', 1))
        if cantidad < 1:
            cantidad = 1
    except (ValueError, TypeError):
        cantidad = 1

    carrito = request.session.get('carrito', {})

    if str(producto_id) in carrito:
        carrito[str(producto_id)]['cantidad'] = cantidad

    request.session['carrito'] = carrito
    messages.success(request, f'Se actualizó la cantidad a {cantidad} para {carrito[str(producto_id)]["nombre_producto"]}.')
    return redirect('ver_carrito')

# Eliminar del carrito
def eliminar_del_carrito(request, producto_id):
    carrito = request.session.get('carrito', {})
    if str(producto_id) in carrito:
        nombre = carrito[str(producto_id)]['nombre_producto']
        del carrito[str(producto_id)]
        messages.success(request, f'Se eliminó {nombre} del carrito.')
    request.session['carrito'] = carrito
    return redirect('ver_carrito')

# Colocar pedido con nombre aleatorio para mostrar en plantilla
@login_required
@transaction.atomic
def colocar_pedido(request):
    nombres_ficticios = ['Leonardo', 'Camila', 'Valentina', 'Mateo', 'Daniela', 'Axel', 'Isabella', 'Luis', 'Sofía', 'Diego']
    nombre_aleatorio = random.choice(nombres_ficticios)

    carrito = request.session.get('carrito', {})
    if not carrito:
        messages.warning(request, "Tu carrito está vacío. Agrega productos para realizar un pedido.")
        return redirect('catalogo')

    pedido = Pedido.objects.create(
        usuario=request.user,
        total=sum(item['precio'] * item['cantidad'] for item in carrito.values()),
        estado='pendiente'
    )

    for producto_id, item in carrito.items():
        producto_obj = Producto.objects.get(id=int(producto_id))
        DetallePedido.objects.create(
            pedido=pedido,
            producto=producto_obj,
            cantidad=item['cantidad'],
            precio_unitario=item['precio']
        )

    request.session['carrito'] = {}
    messages.success(request, f'Su pedido #{pedido.id} se ha realizado exitosamente.')
    return render(request, 'shop/pedido_exitoso.html', {
        'pedido': pedido,
        'nombre_cliente': nombre_aleatorio
    })

# CRUD Producto
class ProductoListView(ListView):
    model = Producto
    template_name = 'shop/producto_list.html'
    context_object_name = 'productos'

class ProductoCreateView(CreateView):
    model = Producto
    form_class = ProductoForm
    template_name = 'shop/producto_form.html'
    success_url = reverse_lazy('producto_list')

class ProductoUpdateView(UpdateView):
    model = Producto
    form_class = ProductoForm
    template_name = 'shop/producto_form.html'
    success_url = reverse_lazy('producto_list')

class ProductoDeleteView(DeleteView):
    model = Producto
    template_name = 'shop/producto_confirm_delete.html'
    success_url = reverse_lazy('producto_list')

# CRUD Categoria
class CategoriaListView(ListView):
    model = Categoria
    template_name = 'shop/categoria_list.html'

class CategoriaCreateView(CreateView):
    model = Categoria
    fields = ['nombre_categoria', 'descripcion']
    template_name = 'shop/categoria_form.html'
    success_url = reverse_lazy('categoria_list')

class CategoriaUpdateView(UpdateView):
    model = Categoria
    fields = ['nombre_categoria', 'descripcion']
    template_name = 'shop/categoria_form.html'
    success_url = reverse_lazy('categoria_list')

class CategoriaDeleteView(DeleteView):
    model = Categoria
    template_name = 'shop/categoria_confirm_delete.html'
    success_url = reverse_lazy('categoria_list')
