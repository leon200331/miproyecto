def base_context(request):
    carrito = request.session.get('carrito', {})
    cantidad_total = sum(item['cantidad'] for item in carrito.values())
    return {'carrito_cantidad': cantidad_total}
